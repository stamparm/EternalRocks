using System;

public enum ProxyType
{
	None,
	Proxy,
	Socks
}
