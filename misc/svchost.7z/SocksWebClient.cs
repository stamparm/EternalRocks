using System;
using System.Net;

public class SocksWebClient : WebClient
{
	public IProxyDetails ProxyDetails
	{
		get;
		set;
	}

	public string UserAgent
	{
		get;
		set;
	}

	protected override WebRequest GetWebRequest(Uri address)
	{
		WebRequest webRequest = null;
		if (this.ProxyDetails != null)
		{
			if (this.ProxyDetails.ProxyType == ProxyType.Proxy)
			{
				webRequest = (HttpWebRequest)WebRequest.Create(address);
				webRequest.Proxy = new WebProxy(this.ProxyDetails.FullProxyAddress);
				if (!string.IsNullOrEmpty(this.UserAgent))
				{
					((HttpWebRequest)webRequest).UserAgent = this.UserAgent;
				}
			}
			else if (this.ProxyDetails.ProxyType == ProxyType.Socks)
			{
				webRequest = SocksHttpWebRequest.Create(address);
				webRequest.Proxy = new WebProxy(this.ProxyDetails.FullProxyAddress);
			}
			else if (this.ProxyDetails.ProxyType == ProxyType.None)
			{
				webRequest = (HttpWebRequest)WebRequest.Create(address);
				if (!string.IsNullOrEmpty(this.UserAgent))
				{
					((HttpWebRequest)webRequest).UserAgent = this.UserAgent;
				}
			}
		}
		else
		{
			webRequest = (HttpWebRequest)WebRequest.Create(address);
			if (!string.IsNullOrEmpty(this.UserAgent))
			{
				((HttpWebRequest)webRequest).UserAgent = this.UserAgent;
			}
		}
		return webRequest;
	}
}
