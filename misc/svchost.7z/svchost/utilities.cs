using System;
using System.Text.RegularExpressions;

namespace svchost
{
	public class utilities
	{
		public static string Encode(string str)
		{
			string arg = string.Format("0-9a-zA-Z{0}", Regex.Escape("-_.!~*'()"));
			return Regex.Replace(str, string.Format("[^{0}]", arg), new MatchEvaluator(utilities.EncodeEvaluator));
		}

		public static string EncodeEvaluator(Match match)
		{
			return (match.Value == " ") ? "+" : string.Format("%{0:X2}", Convert.ToInt32(match.Value[0]));
		}
	}
}
