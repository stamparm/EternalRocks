using System;

namespace svchost
{
	public class Globals
	{
		public static double myVersion = 1.27;

		public static double dVersion = 1.0;

		public static string sInstallDirectory = "C:\\Program Files\\Microsoft Updates";

		public static string sOnion = "http://ubgdgno5eswkhmpy.onion";
	}
}
