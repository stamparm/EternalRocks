using svchost.Installer;
using System;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;

namespace svchost
{
	internal class Program
	{
		private static Mutex mutex = new Mutex(true, "{8F6F0AC4-B9A1-45fd-A8CF-72FDEFF}");

		private static void Main()
		{
			if (Program.mutex.WaitOne(TimeSpan.Zero, true))
			{
				Application.EnableVisualStyles();
				Application.SetCompatibleTextRenderingDefault(false);
				Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
				AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(Program.CurrentDomain_UnhandledException);
				OnRun onRun = new OnRun();
				onRun.Initialize();
				Application.Run();
				Program.mutex.ReleaseMutex();
			}
		}

		private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
		{
			Exception ex = (Exception)e.ExceptionObject;
			EventLog.WriteEntry("svchost", ex.StackTrace + "\r\n" + ex.ToString(), EventLogEntryType.Information);
		}
	}
}
