using System;
using System.Net;

namespace svchost
{
	public class WebclientFactory
	{
		public static SocksWebClient getWebClient()
		{
			return new SocksWebClient
			{
				ProxyDetails = new ProxyDeets(),
				ProxyDetails = 
				{
					FullProxyAddress = "127.0.0.1:9050",
					ProxyAddress = "127.0.0.1",
					ProxyPort = 9050,
					ProxyType = ProxyType.Socks
				}
			};
		}

		public static SocksHttpWebRequest getWebRequest(string url)
		{
			SocksHttpWebRequest socksHttpWebRequest = (SocksHttpWebRequest)SocksHttpWebRequest.Create(url);
			socksHttpWebRequest.Proxy = new WebProxy("127.0.0.1:9050");
			return socksHttpWebRequest;
		}

		public static webclient getMicroWebclient()
		{
			return new webclient();
		}
	}
}
