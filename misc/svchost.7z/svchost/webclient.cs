using System;
using System.IO;
using System.Text;

namespace svchost
{
	public class webclient
	{
		public string post_data(string url, string postData)
		{
			byte[] bytes = Encoding.ASCII.GetBytes(postData);
			SocksHttpWebRequest webRequest = WebclientFactory.getWebRequest(url);
			webRequest.Method = "POST";
			webRequest.ContentType = "application/x-www-form-urlencoded";
			webRequest.ContentLength = (long)bytes.Length;
			Stream requestStream = webRequest.GetRequestStream();
			requestStream.Write(bytes, 0, bytes.Length);
			requestStream.Close();
			SocksHttpWebResponse socksHttpWebResponse = (SocksHttpWebResponse)webRequest.GetResponse();
			Stream responseStream = socksHttpWebResponse.GetResponseStream();
			StreamReader streamReader = new StreamReader(responseStream);
			string text = streamReader.ReadToEnd();
			Console.WriteLine(text);
			return text;
		}
	}
}
