using System;

public static class EncodingHelper
{
	public static string GetEncodingFromChunk(string chunk)
	{
		string text = null;
		int num = chunk.IndexOf("charset=");
		if (num != -1)
		{
			int num2 = chunk.IndexOfAny(new char[]
			{
				' ',
				'"',
				';',
				'\r',
				'\n'
			}, num);
			if (num2 != -1)
			{
				int num3 = num + 8;
				text = chunk.Substring(num3, num2 - num3 + 1);
				text = text.TrimEnd(new char[]
				{
					'>',
					'"',
					'\r',
					'\n'
				});
			}
		}
		return text;
	}
}
