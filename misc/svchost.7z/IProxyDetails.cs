using System;

public interface IProxyDetails
{
	ProxyType ProxyType
	{
		get;
		set;
	}

	string FullProxyAddress
	{
		get;
		set;
	}

	string ProxyAddress
	{
		get;
		set;
	}

	int ProxyPort
	{
		get;
		set;
	}

	string ProxyUserName
	{
		get;
		set;
	}

	string ProxyPassword
	{
		get;
		set;
	}
}
