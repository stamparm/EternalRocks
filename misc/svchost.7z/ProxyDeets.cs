using System;

public class ProxyDeets : IProxyDetails
{
	public ProxyType ProxyType
	{
		get;
		set;
	}

	public string FullProxyAddress
	{
		get;
		set;
	}

	public string ProxyAddress
	{
		get;
		set;
	}

	public int ProxyPort
	{
		get;
		set;
	}

	public string ProxyUserName
	{
		get;
		set;
	}

	public string ProxyPassword
	{
		get;
		set;
	}
}
