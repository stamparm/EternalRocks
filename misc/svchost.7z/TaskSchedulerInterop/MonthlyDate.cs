using System;

namespace TaskSchedulerInterop
{
	internal struct MonthlyDate
	{
		public uint Days;

		public ushort Months;
	}
}
