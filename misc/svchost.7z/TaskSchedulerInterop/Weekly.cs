using System;

namespace TaskSchedulerInterop
{
	internal struct Weekly
	{
		public ushort WeeksInterval;

		public ushort DaysOfTheWeek;
	}
}
