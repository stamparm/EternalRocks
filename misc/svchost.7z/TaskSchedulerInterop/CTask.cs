using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace TaskSchedulerInterop
{
	[Guid("148BD520-A2AB-11CE-B11F-00AA00530503")]
	[ComImport]
	internal class CTask
	{
		[MethodImpl(MethodImplOptions.InternalCall)]
		public extern CTask();
	}
}
