using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace TaskSchedulerInterop
{
	[Guid("148BD52A-A2AB-11CE-B11F-00AA00530503")]
	[ComImport]
	internal class CTaskScheduler
	{
		[MethodImpl(MethodImplOptions.InternalCall)]
		public extern CTaskScheduler();
	}
}
