using System;

namespace TaskSchedulerInterop
{
	internal struct MonthlyDOW
	{
		public ushort WhichWeek;

		public ushort DaysOfTheWeek;

		public ushort Months;
	}
}
