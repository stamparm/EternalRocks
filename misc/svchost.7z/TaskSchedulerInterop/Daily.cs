using System;

namespace TaskSchedulerInterop
{
	internal struct Daily
	{
		public ushort DaysInterval;
	}
}
