using System;
using System.Threading;

namespace Org.Mentalis.Network.ProxySocket
{
	internal class IAsyncProxyResult : IAsyncResult
	{
		internal bool m_Completed = true;

		private object m_StateObject;

		private ManualResetEvent m_WaitHandle;

		public bool IsCompleted
		{
			get
			{
				return this.m_Completed;
			}
		}

		public bool CompletedSynchronously
		{
			get
			{
				return false;
			}
		}

		public object AsyncState
		{
			get
			{
				return this.m_StateObject;
			}
		}

		public WaitHandle AsyncWaitHandle
		{
			get
			{
				if (this.m_WaitHandle == null)
				{
					this.m_WaitHandle = new ManualResetEvent(false);
				}
				return this.m_WaitHandle;
			}
		}

		internal void Init(object stateObject)
		{
			this.m_StateObject = stateObject;
			this.m_Completed = false;
			if (this.m_WaitHandle != null)
			{
				this.m_WaitHandle.Reset();
			}
		}

		internal void Reset()
		{
			this.m_StateObject = null;
			this.m_Completed = true;
			if (this.m_WaitHandle != null)
			{
				this.m_WaitHandle.Set();
			}
		}
	}
}
