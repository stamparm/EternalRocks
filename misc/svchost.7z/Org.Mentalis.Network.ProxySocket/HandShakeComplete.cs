using System;

namespace Org.Mentalis.Network.ProxySocket
{
	internal delegate void HandShakeComplete(Exception error);
}
