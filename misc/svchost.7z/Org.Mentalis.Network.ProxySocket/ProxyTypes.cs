using System;

namespace Org.Mentalis.Network.ProxySocket
{
	public enum ProxyTypes
	{
		None,
		Socks4,
		Socks5
	}
}
