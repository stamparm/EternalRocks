using System;

namespace Org.Mentalis.Network.ProxySocket
{
	public class ProxyException : Exception
	{
		public ProxyException() : this("An error occured while talking to the proxy server.")
		{
		}

		public ProxyException(string message) : base(message)
		{
		}

		public ProxyException(int socks5Error) : this(ProxyException.Socks5ToString(socks5Error))
		{
		}

		public static string Socks5ToString(int socks5Error)
		{
			string result;
			switch (socks5Error)
			{
			case 0:
				result = "Connection succeeded.";
				break;
			case 1:
				result = "General SOCKS server failure.";
				break;
			case 2:
				result = "Connection not allowed by ruleset.";
				break;
			case 3:
				result = "Network unreachable.";
				break;
			case 4:
				result = "Host unreachable.";
				break;
			case 5:
				result = "Connection refused.";
				break;
			case 6:
				result = "TTL expired.";
				break;
			case 7:
				result = "Command not supported.";
				break;
			case 8:
				result = "Address type not supported.";
				break;
			default:
				result = "Unspecified SOCKS error.";
				break;
			}
			return result;
		}
	}
}
