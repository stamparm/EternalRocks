using System;
using System.IO;
using System.Net;
using System.Text;

public class SocksHttpWebResponse : WebResponse
{
	private WebHeaderCollection _httpResponseHeaders;

	private string _responseContent;

	public override WebHeaderCollection Headers
	{
		get
		{
			if (this._httpResponseHeaders == null)
			{
				this._httpResponseHeaders = new WebHeaderCollection();
			}
			return this._httpResponseHeaders;
		}
	}

	public override long ContentLength
	{
		get
		{
			return (long)this.ResponseContent.Length;
		}
		set
		{
			throw new NotSupportedException();
		}
	}

	private string ResponseContent
	{
		get
		{
			return this._responseContent ?? string.Empty;
		}
		set
		{
			this._responseContent = value;
		}
	}

	public Encoding CorrectEncoding
	{
		get;
		set;
	}

	public SocksHttpWebResponse(string httpResponseMessage)
	{
		this.SetHeadersAndResponseContent(httpResponseMessage);
		this.CorrectEncoding = Encoding.Default;
	}

	public SocksHttpWebResponse(string httpResponseMessage, Encoding encoding)
	{
		this.SetHeadersAndResponseContent(httpResponseMessage);
		this.CorrectEncoding = encoding;
	}

	public override Stream GetResponseStream()
	{
		return (this.ResponseContent.Length == 0) ? Stream.Null : new MemoryStream(this.CorrectEncoding.GetBytes(this.ResponseContent));
	}

	public override void Close()
	{
	}

	private void SetHeadersAndResponseContent(string responseMessage)
	{
		if (!string.IsNullOrEmpty(responseMessage))
		{
			int num = responseMessage.IndexOf("\r\n\r\n");
			string text = responseMessage.Substring(0, num);
			string[] array = text.Split(new string[]
			{
				"\r\n"
			}, StringSplitOptions.RemoveEmptyEntries);
			for (int i = 1; i < array.Length; i++)
			{
				string[] array2 = array[i].Split(new char[]
				{
					':'
				});
				this.Headers.Add(array2[0], array2[1]);
			}
			this.ResponseContent = responseMessage.Substring(num + 4);
		}
	}
}
