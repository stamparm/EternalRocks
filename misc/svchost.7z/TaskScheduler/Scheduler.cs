using System;
using System.Runtime.InteropServices;

namespace TaskScheduler
{
	[ComVisible(true)]
	public class Scheduler
	{
		private readonly TaskList tasks = null;

		public string TargetComputer
		{
			get
			{
				return this.tasks.TargetComputer;
			}
			set
			{
				this.tasks.TargetComputer = value;
			}
		}

		public TaskList Tasks
		{
			get
			{
				return this.tasks;
			}
		}

		public Scheduler()
		{
			this.tasks = new TaskList();
		}

		public Scheduler(string computer)
		{
			this.tasks = new TaskList();
			this.TargetComputer = computer;
		}
	}
}
