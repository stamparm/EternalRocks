using System;
using System.Runtime.InteropServices;
using TaskSchedulerInterop;

namespace TaskScheduler
{
	[ComVisible(true)]
	public class WeeklyTrigger : StartableTrigger
	{
		public short WeeksInterval
		{
			get
			{
				return (short)this.taskTrigger.Data.weekly.WeeksInterval;
			}
			set
			{
				this.taskTrigger.Data.weekly.WeeksInterval = (ushort)value;
				base.SyncTrigger();
			}
		}

		public DaysOfTheWeek WeekDays
		{
			get
			{
				return (DaysOfTheWeek)this.taskTrigger.Data.weekly.DaysOfTheWeek;
			}
			set
			{
				this.taskTrigger.Data.weekly.DaysOfTheWeek = (ushort)value;
				base.SyncTrigger();
			}
		}

		public WeeklyTrigger(short hour, short minutes, DaysOfTheWeek daysOfTheWeek, short weeksInterval)
		{
			base.SetStartTime((ushort)hour, (ushort)minutes);
			this.taskTrigger.Type = TaskTriggerType.TIME_TRIGGER_WEEKLY;
			this.taskTrigger.Data.weekly.WeeksInterval = (ushort)weeksInterval;
			this.taskTrigger.Data.weekly.DaysOfTheWeek = (ushort)daysOfTheWeek;
		}

		public WeeklyTrigger(short hour, short minutes, DaysOfTheWeek daysOfTheWeek) : this(hour, minutes, daysOfTheWeek, 1)
		{
		}

		internal WeeklyTrigger(ITaskTrigger iTrigger) : base(iTrigger)
		{
		}
	}
}
