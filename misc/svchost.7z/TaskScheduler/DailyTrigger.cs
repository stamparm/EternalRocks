using System;
using System.Runtime.InteropServices;
using TaskSchedulerInterop;

namespace TaskScheduler
{
	[ComVisible(true)]
	public class DailyTrigger : StartableTrigger
	{
		public short DaysInterval
		{
			get
			{
				return (short)this.taskTrigger.Data.daily.DaysInterval;
			}
			set
			{
				this.taskTrigger.Data.daily.DaysInterval = (ushort)value;
				base.SyncTrigger();
			}
		}

		public DailyTrigger(short hour, short minutes, short daysInterval)
		{
			base.SetStartTime((ushort)hour, (ushort)minutes);
			this.taskTrigger.Type = TaskTriggerType.TIME_TRIGGER_DAILY;
			this.taskTrigger.Data.daily.DaysInterval = (ushort)daysInterval;
		}

		public DailyTrigger(short hour, short minutes) : this(hour, minutes, 1)
		{
		}

		internal DailyTrigger(ITaskTrigger iTrigger) : base(iTrigger)
		{
		}
	}
}
