using System;
using System.Runtime.InteropServices;

namespace TaskScheduler
{
	[ComVisible(true)]
	public enum TaskStatus
	{
		Ready = 267008,
		Running,
		NotScheduled = 267013,
		NeverRun = 267011,
		Disabled = 267010,
		NoMoreRuns = 267012,
		Terminated = 267014,
		NoTriggers,
		NoTriggerTime
	}
}
