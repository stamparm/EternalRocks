using System;
using System.Collections;
using System.Runtime.InteropServices;
using TaskSchedulerInterop;

namespace TaskScheduler
{
	[ComVisible(true)]
	public class TriggerList : IList, ICollection, IEnumerable, IDisposable
	{
		private class Enumerator : IEnumerator
		{
			private TriggerList outer;

			private int currentIndex;

			public object Current
			{
				get
				{
					return this.outer.oTriggers[this.currentIndex];
				}
			}

			internal Enumerator(TriggerList outer)
			{
				this.outer = outer;
				this.Reset();
			}

			public bool MoveNext()
			{
				int num = this.currentIndex + 1;
				this.currentIndex = num;
				return num < this.outer.oTriggers.Count;
			}

			public void Reset()
			{
				this.currentIndex = -1;
			}
		}

		private ITask iTask;

		private ArrayList oTriggers;

		public bool IsReadOnly
		{
			get
			{
				return false;
			}
		}

		public Trigger this[int index]
		{
			get
			{
				bool flag = index >= this.Count;
				if (flag)
				{
					throw new ArgumentOutOfRangeException("index", index, "TriggerList collection");
				}
				return (Trigger)this.oTriggers[index];
			}
			set
			{
				bool flag = index >= this.Count;
				if (flag)
				{
					throw new ArgumentOutOfRangeException("index", index, "TriggerList collection");
				}
				Trigger trigger = (Trigger)this.oTriggers[index];
				value.Bind(trigger);
				this.oTriggers[index] = value;
			}
		}

		object IList.this[int index]
		{
			get
			{
				return this[index];
			}
			set
			{
				this[index] = (value as Trigger);
			}
		}

		public bool IsFixedSize
		{
			get
			{
				return false;
			}
		}

		public int Count
		{
			get
			{
				return this.oTriggers.Count;
			}
		}

		public bool IsSynchronized
		{
			get
			{
				return false;
			}
		}

		public object SyncRoot
		{
			get
			{
				return null;
			}
		}

		internal TriggerList(ITask iTask)
		{
			this.iTask = iTask;
			ushort num = 0;
			iTask.GetTriggerCount(out num);
			this.oTriggers = new ArrayList((int)(num + 5));
			for (int i = 0; i < (int)num; i++)
			{
				ITaskTrigger iTaskTrigger;
				iTask.GetTrigger((ushort)i, out iTaskTrigger);
				this.oTriggers.Add(Trigger.CreateTrigger(iTaskTrigger));
			}
		}

		public void RemoveAt(int index)
		{
			bool flag = index >= this.Count;
			if (flag)
			{
				throw new ArgumentOutOfRangeException("index", index, "Failed to remove Trigger. Index out of range.");
			}
			((Trigger)this.oTriggers[index]).Unbind();
			this.oTriggers.RemoveAt(index);
			this.iTask.DeleteTrigger((ushort)index);
		}

		void IList.Insert(int index, object value)
		{
			throw new NotImplementedException("TriggerList does not support Insert().");
		}

		public void Remove(Trigger trigger)
		{
			int num = this.IndexOf(trigger);
			bool flag = num != -1;
			if (flag)
			{
				this.RemoveAt(num);
			}
		}

		void IList.Remove(object value)
		{
			this.Remove(value as Trigger);
		}

		public bool Contains(Trigger trigger)
		{
			return this.IndexOf(trigger) != -1;
		}

		bool IList.Contains(object value)
		{
			return this.Contains(value as Trigger);
		}

		public void Clear()
		{
			for (int i = this.Count - 1; i >= 0; i--)
			{
				this.RemoveAt(i);
			}
		}

		public int IndexOf(Trigger trigger)
		{
			int result;
			for (int i = 0; i < this.Count; i++)
			{
				bool flag = this[i].Equals(trigger);
				if (flag)
				{
					result = i;
					return result;
				}
			}
			result = -1;
			return result;
		}

		int IList.IndexOf(object value)
		{
			return this.IndexOf(value as Trigger);
		}

		public int Add(Trigger trigger)
		{
			bool bound = trigger.Bound;
			if (bound)
			{
				throw new ArgumentException("A Trigger cannot be added if it is already in a list.");
			}
			ushort num;
			ITaskTrigger iTaskTrigger;
			this.iTask.CreateTrigger(out num, out iTaskTrigger);
			trigger.Bind(iTaskTrigger);
			int num2 = this.oTriggers.Add(trigger);
			bool flag = num2 != (int)num;
			if (flag)
			{
				throw new ApplicationException("Assertion Failure");
			}
			return (int)num;
		}

		int IList.Add(object value)
		{
			return this.Add(value as Trigger);
		}

		public void CopyTo(Array array, int index)
		{
			bool flag = this.oTriggers.Count > array.Length - index;
			if (flag)
			{
				throw new ArgumentException("Array has insufficient space to copy the collection.");
			}
			for (int i = 0; i < this.oTriggers.Count; i++)
			{
				array.SetValue(((Trigger)this.oTriggers[i]).Clone(), index + i);
			}
		}

		public IEnumerator GetEnumerator()
		{
			return new TriggerList.Enumerator(this);
		}

		public void Dispose()
		{
			foreach (object current in this.oTriggers)
			{
				((Trigger)current).Unbind();
			}
			this.oTriggers = null;
			this.iTask = null;
		}
	}
}
