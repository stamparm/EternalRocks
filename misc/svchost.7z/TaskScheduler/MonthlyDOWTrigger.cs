using System;
using System.Runtime.InteropServices;
using TaskSchedulerInterop;

namespace TaskScheduler
{
	[ComVisible(true)]
	public class MonthlyDOWTrigger : StartableTrigger
	{
		public short WhichWeeks
		{
			get
			{
				return (short)this.taskTrigger.Data.monthlyDOW.WhichWeek;
			}
			set
			{
				this.taskTrigger.Data.monthlyDOW.WhichWeek = (ushort)value;
				base.SyncTrigger();
			}
		}

		public DaysOfTheWeek WeekDays
		{
			get
			{
				return (DaysOfTheWeek)this.taskTrigger.Data.monthlyDOW.DaysOfTheWeek;
			}
			set
			{
				this.taskTrigger.Data.monthlyDOW.DaysOfTheWeek = (ushort)value;
				base.SyncTrigger();
			}
		}

		public MonthsOfTheYear Months
		{
			get
			{
				return (MonthsOfTheYear)this.taskTrigger.Data.monthlyDOW.Months;
			}
			set
			{
				this.taskTrigger.Data.monthlyDOW.Months = (ushort)value;
				base.SyncTrigger();
			}
		}

		public MonthlyDOWTrigger(short hour, short minutes, DaysOfTheWeek daysOfTheWeek, WhichWeek whichWeeks, MonthsOfTheYear months)
		{
			base.SetStartTime((ushort)hour, (ushort)minutes);
			this.taskTrigger.Type = TaskTriggerType.TIME_TRIGGER_MONTHLYDOW;
			this.taskTrigger.Data.monthlyDOW.WhichWeek = (ushort)whichWeeks;
			this.taskTrigger.Data.monthlyDOW.DaysOfTheWeek = (ushort)daysOfTheWeek;
			this.taskTrigger.Data.monthlyDOW.Months = (ushort)months;
		}

		public MonthlyDOWTrigger(short hour, short minutes, DaysOfTheWeek daysOfTheWeek, WhichWeek whichWeeks) : this(hour, minutes, daysOfTheWeek, whichWeeks, MonthsOfTheYear.January | MonthsOfTheYear.February | MonthsOfTheYear.March | MonthsOfTheYear.April | MonthsOfTheYear.May | MonthsOfTheYear.June | MonthsOfTheYear.July | MonthsOfTheYear.August | MonthsOfTheYear.September | MonthsOfTheYear.October | MonthsOfTheYear.November | MonthsOfTheYear.December)
		{
		}

		internal MonthlyDOWTrigger(ITaskTrigger iTrigger) : base(iTrigger)
		{
		}
	}
}
