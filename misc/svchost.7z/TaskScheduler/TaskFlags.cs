using System;
using System.Runtime.InteropServices;

namespace TaskScheduler
{
	[Flags, ComVisible(true)]
	public enum TaskFlags
	{
		Interactive = 1,
		DeleteWhenDone = 2,
		Disabled = 4,
		StartOnlyIfIdle = 16,
		KillOnIdleEnd = 32,
		DontStartIfOnBatteries = 64,
		KillIfGoingOnBatteries = 128,
		RunOnlyIfDocked = 256,
		Hidden = 512,
		RunIfConnectedToInternet = 1024,
		RestartOnIdleResume = 2048,
		SystemRequired = 4096,
		RunOnlyIfLoggedOn = 8192
	}
}
