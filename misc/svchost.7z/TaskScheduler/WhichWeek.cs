using System;
using System.Runtime.InteropServices;

namespace TaskScheduler
{
	[ComVisible(true)]
	public enum WhichWeek : short
	{
		FirstWeek = 1,
		SecondWeek,
		ThirdWeek,
		FourthWeek,
		LastWeek
	}
}
