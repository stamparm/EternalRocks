using System;
using System.Runtime.InteropServices;
using TaskSchedulerInterop;

namespace TaskScheduler
{
	[ComVisible(true)]
	public class OnSystemStartTrigger : Trigger
	{
		public OnSystemStartTrigger()
		{
			this.taskTrigger.Type = TaskTriggerType.EVENT_TRIGGER_AT_SYSTEMSTART;
		}

		internal OnSystemStartTrigger(ITaskTrigger iTrigger) : base(iTrigger)
		{
		}
	}
}
