using System;
using System.Runtime.InteropServices;
using TaskSchedulerInterop;

namespace TaskScheduler
{
	[ComVisible(true)]
	public class RunOnceTrigger : StartableTrigger
	{
		public RunOnceTrigger(DateTime runDateTime)
		{
			this.taskTrigger.BeginYear = (ushort)runDateTime.Year;
			this.taskTrigger.BeginMonth = (ushort)runDateTime.Month;
			this.taskTrigger.BeginDay = (ushort)runDateTime.Day;
			base.SetStartTime((ushort)runDateTime.Hour, (ushort)runDateTime.Minute);
			this.taskTrigger.Type = TaskTriggerType.TIME_TRIGGER_ONCE;
		}

		internal RunOnceTrigger(ITaskTrigger iTrigger) : base(iTrigger)
		{
		}
	}
}
