using System;
using System.Runtime.InteropServices;
using TaskSchedulerInterop;

namespace TaskScheduler
{
	[ComVisible(true)]
	public abstract class StartableTrigger : Trigger
	{
		public short StartHour
		{
			get
			{
				return (short)this.taskTrigger.StartHour;
			}
			set
			{
				bool flag = value < 0 || value > 23;
				if (flag)
				{
					throw new ArgumentOutOfRangeException("hour", value, "hour must be between 0 and 23");
				}
				this.taskTrigger.StartHour = (ushort)value;
				base.SyncTrigger();
			}
		}

		public short StartMinute
		{
			get
			{
				return (short)this.taskTrigger.StartMinute;
			}
			set
			{
				bool flag = value < 0 || value > 59;
				if (flag)
				{
					throw new ArgumentOutOfRangeException("minute", value, "minute must be between 0 and 59");
				}
				this.taskTrigger.StartMinute = (ushort)value;
				base.SyncTrigger();
			}
		}

		internal StartableTrigger()
		{
		}

		internal StartableTrigger(ITaskTrigger iTrigger) : base(iTrigger)
		{
		}

		protected void SetStartTime(ushort hour, ushort minute)
		{
			this.StartHour = (short)hour;
			this.StartMinute = (short)minute;
		}
	}
}
