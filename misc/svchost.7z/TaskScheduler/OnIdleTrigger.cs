using System;
using System.Runtime.InteropServices;
using TaskSchedulerInterop;

namespace TaskScheduler
{
	[ComVisible(true)]
	public class OnIdleTrigger : Trigger
	{
		public OnIdleTrigger()
		{
			this.taskTrigger.Type = TaskTriggerType.EVENT_TRIGGER_ON_IDLE;
		}

		internal OnIdleTrigger(ITaskTrigger iTrigger) : base(iTrigger)
		{
		}
	}
}
