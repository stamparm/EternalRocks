using System;
using System.Collections;
using System.Runtime.InteropServices;

namespace TaskScheduler
{
	[ComVisible(true)]
	public class TaskList : IEnumerable, IDisposable
	{
		private class Enumerator : IEnumerator
		{
			private ScheduledTasks outer;

			private string[] nameTask;

			private int curIndex;

			private Task curTask;

			public object Current
			{
				get
				{
					return this.curTask;
				}
			}

			internal Enumerator(ScheduledTasks st)
			{
				this.outer = st;
				this.nameTask = st.GetTaskNames();
				this.Reset();
			}

			public bool MoveNext()
			{
				int num = this.curIndex + 1;
				this.curIndex = num;
				bool flag = num < this.nameTask.Length;
				bool flag2 = flag;
				if (flag2)
				{
					this.curTask = this.outer.OpenTask(this.nameTask[this.curIndex]);
				}
				return flag;
			}

			public void Reset()
			{
				this.curIndex = -1;
				this.curTask = null;
			}
		}

		private ScheduledTasks st = null;

		private string nameComputer;

		internal string TargetComputer
		{
			get
			{
				return this.nameComputer;
			}
			set
			{
				this.st.Dispose();
				this.st = new ScheduledTasks(value);
				this.nameComputer = value;
			}
		}

		public Task this[string name]
		{
			get
			{
				return this.st.OpenTask(name);
			}
		}

		internal TaskList()
		{
			this.st = new ScheduledTasks();
		}

		internal TaskList(string computer)
		{
			this.st = new ScheduledTasks(computer);
		}

		public Task NewTask(string name)
		{
			return this.st.CreateTask(name);
		}

		public void Delete(string name)
		{
			this.st.DeleteTask(name);
		}

		public IEnumerator GetEnumerator()
		{
			return new TaskList.Enumerator(this.st);
		}

		public void Dispose()
		{
			this.st.Dispose();
		}
	}
}
